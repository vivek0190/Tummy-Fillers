<?php

include('session_m.php');
// require 'connection.php';
// $con = Connect();

if(!isset($login_session)){
header('Location: managerlogin.php'); // Redirecting To Home Page
}

         $sql ="SELECT SUM(o.quantity) as 'quantity',o.F_ID,f.name 'name' FROM `orders_product_details` o
         INNER JOIN food f
         ON f.F_ID = o.F_ID
        --  WHERE o.order_date <='' AND o.order_date >=''
         GROUP BY F_ID
         ORDER BY quantity desc LIMIT 5";
         $result = mysqli_query($conn,$sql);
         $chart_data="";
         while ($row = mysqli_fetch_assoc($result)) { 
 
            $productname[]  = $row['name']  ;
            $sales[] = $row['quantity'];
        }
        $row1 = mysqli_fetch_assoc($result);
        echo "AA <pre>";
        print_r($row1);
        echo "</pre>";
 
?>

<!DOCTYPE html>
<html lang="en"> 
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Graph</title> 
    </head>
    <body>
        <div style="width:60%;hieght:20%;text-align:center">
            <h2 class="page-header" >Analytics Reports </h2>
            <div>Product </div>
            <canvas  id="chartjs_bar"></canvas> 
        </div>    
    </body>
  <script src="//code.jquery.com/jquery-1.9.1.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script type="text/javascript">
      var ctx = document.getElementById("chartjs_bar").getContext('2d');
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels:<?php echo json_encode($productname); ?>,
                        datasets: [{
                            backgroundColor: [
                               "#5969ff",
                                "#ff407b",
                                "#25d5f2",
                                "#ffc750",
                                "#2ec551",
                                "#7040fa",
                                "#ff004e"
                            ],
                            data:<?php echo json_encode($sales); ?>,
                        }]
                    },
                    options: {
                           legend: {
                        display: true,
                        position: 'bottom',
 
                        labels: {
                            fontColor: '#71748d',
                            fontFamily: 'Circular Std Book',
                            fontSize: 14,
                        }
                    },
 
 
                }
                });
    </script>
</html>



