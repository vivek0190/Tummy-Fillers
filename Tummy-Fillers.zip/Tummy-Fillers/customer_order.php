<?php
include('session_u.php');

if(!isset($login_session)){
header('Location: customerlogin.php'); // Redirecting To Home Page
}

if(isset($_GET['status']) && $_GET['status']=='done'){
    unset($_SESSION['cart']);
}
?>


<!DOCTYPE html>
<html>

<head>
    <title> Delivery Boy Login | Tummy Fillers </title>
</head>

<link rel="stylesheet" type="text/css" href="css/myrestaurant.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/delivery_boy.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<body>
    <button onclick="topFunction()" id="myBtn" title="Go to top">
        <i class="fa fa-arrow-circle-up"></i>
    </button>

    <script type="text/javascript">
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("myBtn").style.display = "block";
        } else {
            document.getElementById("myBtn").style.display = "none";
        }
    }

    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
    </script>

    <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand">Tummy Fillers</a>
            </div>

            <div class="collapse navbar-collapse " id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>

                </ul>

                <?php
if(isset($_SESSION['login_user1'])){

?>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome
                            <?php echo $_SESSION['login_user1']; ?> </a></li>
                    <li><a href="myrestaurant.php">MANAGER CONTROL PANEL</a></li>
                    <li><a href="logout_m.php"><span class="glyphicon glyphicon-log-out"></span> Log Out </a></li>
                </ul>
                <?php
}
else if (isset($_SESSION['login_user2'])) {
  ?>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="foodlist.php"><i class="fa fa-user"></i>&nbsp; Welcome
                            <?php echo $_SESSION['login_user2']; ?> </a></li>
                    <li><a href="foodlist.php"><i class="	fa fa-coffee"></i> &nbsp; Food Zone </a></li>
                    <li><a href="cart.php"><i class="fa fa-shopping-cart"></i>&nbsp; Cart
                            (<?php
              if(isset($_SESSION["cart"])){
              $count = count($_SESSION["cart"]); 
              echo "$count"; 
            }
              else
                echo "0";
              ?>)
                        </a></li>
                    <li><a href="customer_order.php"><i class="fa fa-eject"></i>&nbsp; Check Order </a></li>
                    <li><a href="logout_u.php"><i class="fa fa-sign-out"></i>&nbsp; Log Out </a></li>
                </ul>
                <?php        
}
else if (isset($_SESSION['login_user3'])) {
  ?>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome
                            <?php echo $_SESSION['login_user3']; ?> </a></li>
                    <li><a href="delivery_boy.php">DELIVERY BOY CONTROL PANEL</a></li>
                    <li><a href="logout_d.php"><span class="glyphicon glyphicon-log-out"></span> Log Out </a></li>
                </ul>

                <?php
  }

else {
  ?>

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button"
                            aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span>
                            Sign Up <span class="caret"></span> </a>
                        <ul class="dropdown-menu">
                            <li> <a href="customersignup.php"> User Sign-up</a></li>
                            <li> <a href="managersignup.php"> Manager Sign-up</a></li>
                        </ul>
                    </li>

                    <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button"
                            aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-log-in"></span>
                            Login <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li> <a href="customerlogin.php"> User Login</a></li>
                            <li> <a href="managerlogin.php"> Manager Login</a></li>
                        </ul>
                    </li>
                </ul>

                <?php
}
?>
            </div>
        </div>
    </nav>

    <!-- <div class="container">
    <div class="jumbotron">
     <h1>Hello Delivery Boy ! </h1>
     <p>View all your orders from here</p>

    </div>
    </div> -->
    <div class="container">
        <div class="container">
            <div class="col">
                <?php
        // echo "<br><br>".$_GET['status'];
        if(isset($_GET['status']) && $_GET['status']=='done'){
        ?>
                <div class="jumbotron">
                    <h1 class="text-center" style="color: green;"><i class="fa fa-thumbs-o-up"></i> Order Placed
                        Successfully.</h1>
                </div>
                <?php  }?>
            </div>
        </div>


        <div class="col-xs-12 center">
            <div class="form-area" style="padding: 0px 100px 100px 100px;">
                <form action="delivery_boy_assign.php" method="POST">
                    <br style="clear: both;">
                    <h3 style="margin-bottom: 25px; text-align: center; font-size: 30px;"> YOUR FOOD ORDER LIST </h3>


                    <?php


// Storing Session
$user_check= $_SESSION['login_user2'];
// echo $user_check;
$sql = "SELECT o.`order_ID`, o.`F_ID`, o.`foodname`, o.`price`, o.`quantity`, o.`order_date`,
o.`order_time`, o.`username`, o.`R_ID`, o.`status`,IFNULL(d.`fullname`,'Not Assigned') as d_id,IFNULL(d.`mobile_no`,'Not Assigned') as mobile_no,o.`deliver_time`
FROM `orders` as o LEFT JOIN delivery_boy as d
on d.D_ID = o.d_id
where o.username='$user_check' ORDER BY o.order_ID DESC";
// echo $user_check;
// echo $sql;
$result = mysqli_query($conn, $sql);
// echo mysqli_num_rows($result );
if (mysqli_num_rows($result ) > 0  )
{
  ?>

                    <table class="table table-striped">


                        <?PHP
      //OUTPUT DATA OF EACH ROW
          while($row = mysqli_fetch_assoc($result))  {
    ?>
                        <tbody>
                            <tr>
                                <td></td>
                            </tr>
                            <tr>
                                <th> #</th>
                                <th> Order ID </th>
                                <th> </th>
                                <th> Order Date/Time </th>
                                <th> </th>
                                <th> </th>
                                <th> </th>
                                <!-- <th> Customer </th> -->
                                <th> Delivery Boy </th>
                                <th> Status</th>
                                <th> Mobile NO </th>
                                <th> Deliver Time</th>
                            </tr>


                            <tr style="border-style: solid;border-color: #333;">
                                <td class="text-success alert alert-success"> Order Details
                                </td>
                                <td><?php echo $row["order_ID"]; ?></td>
                                <td></td>
                                <td><?php echo $row["order_date"].' '.$row["order_time"]; ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><?php  echo $row["d_id"]; ?></td>
                                <td><?php echo $row["status"]; ?></td>
                                <td><?php echo $row["mobile_no"]; ?> </td>
                                <td><?php echo $row["deliver_time"]; ?></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5
                                        style="padding:5px;background-color:#333;color:white;text-align:center;border-radius:5px;">
                                        Items Details</h5>
                                </td>
                            </tr>

                            <tr style="background-color:#eee;">
                                <th scope="col">#</th>
                                <th></th>
                                <th scope="col">Food Item</th>
                                <th></th>
                                <th scope="col">Quantity</th>
                                <th></th>
                                <th scope="col">Price</th>
                                <th></th>
                                <th scope="col">Total</th>

                            </tr>

                            <?php

                                $grand_total = 0;
                          $sql1 = "SELECT o.`order_ID`, o.`F_ID`, o.`foodname`, o.`price`, o.`quantity`, o.`order_date`,
                           o.`order_time`, o.`username`, o.`R_ID`, o.`status`FROM `orders_product_details` as o 
                          where o.order_id= '$row[order_ID]'";
// echo $user_check;
// echo $sql;
                          $result1 = mysqli_query($conn, $sql1);
// echo $D_ID;
                          if (mysqli_num_rows($result1 ) > 0  )
                          {
                            $i=0;
                            while($row1 = mysqli_fetch_assoc($result1))  {
                              $i++;
                           ?>
                            <tr>
                                <th scope="row"><?php echo $i; ?></th>
                                <td></td>
                                <td><?php echo $row1["foodname"];?></td>
                                <td></td>
                                <td><?php echo $row1["quantity"];?></td>
                                <td></td>
                                <td><?php echo $row1["price"];?></td>
                                <td></td>
                                <td ><?php $grand_total = $grand_total + $row1["quantity"] * $row1["price"]; echo $row1["quantity"] * $row1["price"];?>
                                </td>

                            </tr>

            </div>
        </div>
        <?php }}else{?>
        <tr>
            <td>No Food Details </td>
        </tr>

        <?php }?>
        <tr>
            <th scope="row"><?php  ?></th>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class = "alert alert-info"><B><?php echo "Grand Total "?></td>
            <td></td>
            <td class = "alert alert-info"><b><?php echo $grand_total;?></td>

        </tr>


        </tbody>

        <?php
// }
}  
?>
        </table>
        <br>

        <?php } else { ?>

        <h4>
            <center>0 RESULTS</center>
        </h4>

        <?php } ?>

        </form>


    </div>

    </div>
    </div>
</body>

</html>