<?php

include('session_m.php');

if(!isset($login_session)){
header('Location: managerlogin.php'); 
}

// echo $_GET['data'];
$delivery_boy_id = $conn->real_escape_string($_GET['d_id']);
$order_id = $conn->real_escape_string($_GET['o_id']);
$delieryboy_update= "UPDATE delivery_boy SET status='DISABLE' WHERE D_ID = $delivery_boy_id";
$order_update =  "UPDATE orders SET D_ID = $delivery_boy_id WHERE order_ID = $order_id";
// echo $delieryboy_update;
$success = $conn->query($delieryboy_update);
$success1 = $conn->query($order_update);

// echo $order_update;

if($success and $success1){
    // header('Location: view_order_details.php');
    echo "<script>window.close();</script>";

    // echo $success;
    // echo $success1;
}else{
    // echo $success;
    // echo $success1;
}
?>










