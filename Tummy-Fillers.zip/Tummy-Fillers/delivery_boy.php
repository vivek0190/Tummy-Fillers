<?php
include('session_d.php');

if(!isset($login_session)){
header('Location: delivery_boy_login.php'); // Redirecting To Home Page
}
?>

<!DOCTYPE html>
<html>

<head>
    <title> Delivery Boy Login | Tummy Fillers </title>
</head>

<link rel="stylesheet" type="text/css" href="css/myrestaurant.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/delivery_boy.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<body>
    <button onclick="topFunction()" id="myBtn" title="Go to top">
        <i class="fa fa-arrow-circle-up"></i>
    </button>

    <script type="text/javascript">
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("myBtn").style.display = "block";
        } else {
            document.getElementById("myBtn").style.display = "none";
        }
    }

    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
    </script>

    <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand">Tummy Fillers</a>
            </div>

            <div class="collapse navbar-collapse " id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="delivery_boy.php"><i class="fa fa-user"></i>&nbsp; Welcome
                            <?php echo $login_session; ?> </a></li>
                    <li class="active"> <a href="delivery-boy-login.php">DELIVERY BOY CONTROL PANEL</a></li>
                    <li><a href="logout_m.php"><i class="fa fa-sign-out"></i>&nbsp; Log Out </a></li>
                </ul>
            </div>

        </div>
    </nav>

    <div class="container">
        <div class="jumbotron">
            <h1>Hello Delivery Boy ! </h1>
            <p>View all your orders from here</p>

        </div>
    </div>
    <div class="container">
        <div class="container">
            <div class="col">

            </div>
        </div>


        <div class="col-xs-9 center">
            <div class="form-area" style="padding: 0px 100px 100px 100px;">
                <form action="delivery_boy_assign.php" method="POST">
                    <br style="clear: both;">
                    <h3 style="margin-bottom: 25px; text-align: center; font-size: 30px;"> YOUR FOOD ORDER LIST </h3>


                    <?php

// Storing Session
$user_check= $_SESSION['login_user3'];
$sql = "SELECT * FROM orders WHERE D_ID=$_SESSION[d_id] ORDER BY order_ID desc ";
// echo $_SESSION['login_user3'];
$result = mysqli_query($conn, $sql);
// echo $D_ID;
if (mysqli_num_rows($result ) > 0 )
{

  ?>

                    <table class="table table-striped">
                        <thead class="thead-dark">

                        </thead>

                        <?PHP
      //OUTPUT DATA OF EACH ROW
          while($row = mysqli_fetch_assoc($result))  {
    ?>

                        <tbody>
                            <tr>
                                <th> </th>
                                <th> D_ID </th>
                                <th> Order ID </th>
                                <th> </th>
                                <th> Order Date/Time </th>
                                <th> </th>
                                <th>  </th>
                                <th>  </th>
                                <th> Customer </th>
                                <th> Status</th>
                                <th></th>
                                <th> Deliver/Time</th>
                            </tr>
                            <tr>
                                <td><i class="fa fa-circle"></i></td>
                                <td><?php  echo $row["d_id"]; ?></td>
                                <td><?php echo $row["order_ID"]; ?></td>
                                <td></td>
                                <td><?php echo $row["order_date"]." ".$row["order_time"]; ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><?php echo $row["username"]; ?></td>
                                <td><?php echo $row["status"]; ?></td>
                                <!-- <td>
                                    <a type="button" href="delivery_boy1.php?o_id=<?php echo $row["order_ID"];?>"
                                        class="btn btn-primary" name="assign" id="assign">
                                        Deliver</a>
                                </td> -->
                                <td>
                                <?php if($row["status"]!='DELIVERED'){
                                  ?>
                                     <a type="button" href="delivery_boy1.php?o_id=<?php echo $row["order_ID"];?>"
                                        class="btn btn-primary" name="assign" id="assign">
                                        Deliver</a>
                                  <?php
                                      }?>
                                </td>
                                <td><?php echo $row["deliver_time"]; ?></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5
                                        style="padding:5px;background-color:#333;color:white;text-align:center;border-radius:5px;">
                                        Items Details</h5>
                                </td>
                            </tr>


                            <tr style="background-color:#eee;">
                                <th scope="col">#</th>
                                <th></th>
                                <th scope="col">Food Item</th>
                                <th></th>
                                <th scope="col">Quantity</th>
                                <th></th>
                                <th></th>
                                <th scope="col">Price</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th scope="col">Total</th>

                            </tr>

                            <?php

$grand_total = 0;
$sql1 = "SELECT o.`order_ID`, o.`F_ID`, o.`foodname`, o.`price`, o.`quantity`, o.`order_date`,
o.`order_time`, o.`username`, o.`R_ID`, o.`status`FROM `orders_product_details` as o 
where o.order_id= '$row[order_ID]'";
// echo $user_check;
// echo $sql;
$result1 = mysqli_query($conn, $sql1);
// echo $D_ID;
if (mysqli_num_rows($result1 ) > 0  )
{
$i=0;
while($row1 = mysqli_fetch_assoc($result1))  {
$i++;
?>

<tr>
                                <th scope="row"><?php echo $i; ?></th>
                                <td></td>
                                <td><?php echo $row1["foodname"];?></td>
                                <td></td>
                                <td><?php echo $row1["quantity"];?></td>
                                <td></td>
                                <td></td>
                                <td><?php echo $row1["price"];?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><?php $grand_total = $grand_total + $row1["quantity"] * $row1["price"]; echo $row1["quantity"] * $row1["price"];?>
                                </td>

                            </tr>

            </div>
        </div>
        <?php }}else{?>
        <tr>
            <td>No Food Details </td>
        </tr>

        <?php }?>
        <tr>
            <th scope="row"><?php  ?></th>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class = "alert alert-info"><B><?php echo "Grand Total "?></td>
            <td></td>
            
            <td class = "alert alert-info"> <b><?php echo $grand_total;?></td>

        </tr>
                        </tbody>

                        <?php }  ?>
                    </table>
                    <br>

                    <?php } else { ?>

                    <h4>
                        <center>0 RESULTS</center>
                    </h4>

                    <?php } ?>

                </form>


            </div>

        </div>
    </div>
</body>

</html>