<?php
session_start();
require 'connection.php';
$conn = Connect();
if(!isset($_SESSION['login_user2'])){
header("location: customerlogin.php"); 
}

// unset($_SESSION["cart"]);
?>

<html>

  <head>
    <title> Cart | Tummy Fillers </title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="css/COD.css">
  <link rel="stylesheet" type = "text/css" href ="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>

  <body>

  
    <button onclick="topFunction()" id="myBtn" title="Go to top">
    <i class="fa fa-arrow-circle-up"></i>
    </button>
  
    <script type="text/javascript">
      window.onscroll = function()
      {
        scrollFunction()
      };

      function scrollFunction(){
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          document.getElementById("myBtn").style.display = "block";
        } else {
          document.getElementById("myBtn").style.display = "none";
        }
      }

      function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      }
      function clear(){
      }

      function deliver(orderId){
        console.log(orderId);
        var hostname = window.location.hostname+":"+window.location.port;
          window.location.replace("http://"+hostname+"/Tummy-Fillers/customer_order.php?status=done");
      }
    </script>

    <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">Tummy Fillers</a>
        </div>

        <div class="collapse navbar-collapse " id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>

          </ul>

<?php
if(isset($_SESSION['login_user1'])){

?>


          <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome <?php echo $_SESSION['login_user1']; ?> </a></li>
            <li><a href="myrestaurant.php">MANAGER CONTROL PANEL</a></li>
            <li><a href="logout_m.php"><span class="glyphicon glyphicon-log-out"></span> Log Out </a></li>
          </ul>
<?php
}
else if (isset($_SESSION['login_user2'])) {
  ?>
           <ul class="nav navbar-nav navbar-right">
            <li><a href="foodlist.php"><i class="fa fa-user"></i>&nbsp; Welcome <?php echo $_SESSION['login_user2']; ?> </a></li>
            <li><a href="foodlist.php"><i class="	fa fa-coffee"></i> &nbsp; Food Zone </a></li>
            <li><a href="cart.php"><i class="fa fa-shopping-cart"></i>&nbsp; Cart
             (<?php
              if(isset($_SESSION["cart"])){
              $count = count($_SESSION["cart"]); 
              echo "$count"; 
            }
              else
                echo "0";
              ?>)
              </a></li>
              <li><a href="customer_order.php"><i class="fa fa-eject"></i>&nbsp; Check Order </a></li>
            <li><a href="logout_u.php"><i class="fa fa-sign-out"></i>&nbsp; Log Out </a></li>
          </ul>
  <?php        
}
else {

  ?>

<ul class="nav navbar-nav navbar-right">
            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> Sign Up <span class="caret"></span> </a>
                <ul class="dropdown-menu">
              <li> <a href="customersignup.php"> User Sign-up</a></li>
              <li> <a href="managersignup.php"> Manager Sign-up</a></li>
            </ul>
            </li>

            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-log-in"></span> Login <span class="caret"></span></a>
              <ul class="dropdown-menu">
              <li> <a href="customerlogin.php"> User Login</a></li>
              <li> <a href="managerlogin.php"> Manager Login</a></li>
            </ul>
            </li>
          </ul>

<?php
}
?>


        </div>

      </div>
    </nav>



        <div class="container">
          
          <div class="jumbotron">
            <h1 class="text-center" style="color: green;"><i class="fa fa-thumbs-o-up"></i> Order Placed Successfully.</h1>
          </div>
        </div>
        <br>

<!-- <h2 class="text-center"> Thank you for Ordering at Tummy Fillers! The ordering process is now complete.</h2> -->

<?php 
  // $num1 = rand(100000,999999); 
  // $num2 = rand(100000,999999); 
  // $num3 = rand(100000,999999);
  // $number = $num1.$num2.$num3;
  // if(count($_SESSION["cart"])  >  0){
    
    // echo "Hellloooooooooo";
    // echo "<pre>";
    // echo ($_SESSION["login_user2"]);
    // echo "</pre>";
    // print_r ($_SESSION);
    // echo "<br><br>". $_SESSION["cart"][0]['R_ID'];
        
    if(count($_SESSION["cart"])  >  0){
      $username = $_SESSION["login_user2"];
      $order_date = date('Y-m-d');
      $order_time = date('H:i:s');
      $R_ID = $_SESSION["cart"][0]['R_ID'];

      // $R_ID = $values["R_ID"];
     
      // DB Query Start
      $query = "INSERT INTO ORDERS (order_date,order_time,username, R_ID) 
      VALUES ('" . $order_date . "','" . $order_time ."','" . $username . "','" . $R_ID . "')";
      $success = $conn->query($query);

      $order_id =  mysqli_insert_id($conn);
      // echo "<br>".$success;
      // DB Query END

      $gtotal = 0;
      // header('Location:COD.php');

      ?>
<div class="container">
            <h3 class="text-center">Order Details</h5>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Order Date</th>
      <th scope="col">Order Time</th>
      <!-- <th scope="col">Handle</th> -->
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Order</th>
      <td><?php echo $order_date ?></td>
      <td><?php echo $order_time ?></td>
      <!-- <td>@mdo</td> -->
    </tr>
  </tbody>
</table>
          </div>
          <div class="container">
          <h3 class="text-center">Item Details</h3>
            
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Item Name</th>
      <th scope="col">Quantity</th>
      <th scope="col">Price</th>
      <th scope="col">Total</th>

      <!-- <th scope="col">Handle</th> -->
    </tr>
  </thead>
      <?php

        foreach($_SESSION["cart"] as $keys => $values)
          {
            $F_ID = $values["food_id"];
            $foodname = $values["food_name"];
            $quantity = $values["food_quantity"];
            $price =  $values["food_price"];
            $total = ($values["food_quantity"] * $values["food_price"]);
            $R_ID = $values["R_ID"];
            // $username = $_SESSION["login_user2"];
            $order_date = date('Y-m-d');
            $order_time = date('H:i:s');
            // $D_ID = $_SESSION["login_user2"]["D_ID"];
            $gtotal = $gtotal + $total;
?>
          <!-- HTML TABLE OF PRODUCT DETAIL -->

          
  <tbody>
    <tr>
      <th scope="row"><i class="fa fa-circle"></i></th>
      <td><?php echo $foodname ?></td>
      <td><?php echo $quantity ?></td>
      <td><?php echo $price ?></td>
      <td><?php echo $quantity * $price ?></td>
      <!-- <td>@mdo</td> -->
    </tr>
  </tbody>


<?php
            $query = "INSERT INTO ORDERS_PRODUCT_DETAILS (order_id,F_ID, foodname, price,  quantity,
               order_date,order_time, username, R_ID) 
              VALUES ('" . $order_id . "','" . $F_ID . "','" . $foodname . "','" . $price . "','" . $quantity . "',
              '" . $order_date . "','" . $order_time ."','" . $username . "','" . $R_ID . "')";
             
            // echo $query;
            $success = $conn->query($query);         
            // echo $success;

          }
          ?>
          </table>
          </div>
          <?php
          // unset($_SESSION['cart']);
          echo "<script>deliver();</script>";

      }
?> 
   
</a>
        <br>
<h1 class="text-center">Grand Total: &#8377;<?php echo "$gtotal"; ?>/-</h1>
<h5 class="text-center">including all service charges. (no delivery charges applied)</h5>
<br>
<h1 class="text-center">
  <!-- <a href="cart.php"><button class="btn btn-warning"><i class="fa fa-shopping-cart"></i>&nbsp; Go back to cart</button></a> -->
  <!-- pay onlie-->
  <!-- <a href="onlinepay.php" style="display:none;"><button class="btn btn-success"><span class="glyphicon glyphicon-credit-card"></span> Pay Online</button></a> -->
  <!-- <a href="customer_order.php"><button class="btn btn-success">Cash On Delivery</button></a> -->
</h1>

<a href="customer_order.php">
    <button  class="btn btn-danger" type="submit" 
    style="margin:0px 0px 0px 1200px; height:50px; border: radius 5px;" onClick="clear();">
      Check Orders
    </button>
        </body>

</html>