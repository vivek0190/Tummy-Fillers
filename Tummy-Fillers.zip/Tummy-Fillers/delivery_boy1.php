<?php

include('session_d.php');

if(!isset($login_session)){
header('Location: delivery_boy.php'); 
}

    $query = "UPDATE delivery_boy SET status='AVAILABLE' WHERE D_ID = $_SESSION[d_id]";
    // echo $query;

    $deliver_time = date('H:i:s');
    // echo $deliver_time;
    $query1 = "UPDATE orders SET status='DELIVERED', deliver_time='$deliver_time' WHERE order_ID = $_GET[o_id]";
    // echo "<br>".$query1;
    $success = $conn->query($query);
    $success1 = $conn->query($query1);

    // echo "<br> Success ".$success;
    // echo "<br> Success->".$success1;
    header("location:delivery_boy.php");
?>